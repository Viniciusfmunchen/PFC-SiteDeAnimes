<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['title' => 'Editar Anime']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Editar Anime']); ?>
    <form action="<?php echo e(route('animes.update', $anime->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row mt-3">
            <div class="form-group col-8">
                <label for="name" class="form-label">Nome:</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($anime->name); ?>">
            </div>
            <div class="form-group col-4">
                <label for="date" class="form-label">Data de lançamento:</label>
                <input type="date" name="date" id="date" class="form-control" value="<?php echo e($anime->date); ?>">
            </div>
        </div>
        <div class="row mt-3">
            <div class="form-group col-6">
                <label for="episodes" class="form-label">Quantidade de episodios:</label>
                <input type="number" name="episodes" id="episodes" class="form-control" value="<?php echo e($anime->episodes); ?>">
            </div>
            <div class="form-group col-6">
                <label for="seasons" class="form-label">Quantidade de Temporadas:</label>
                <input type="number" name="seasons" id="seasons" class="form-control" value="<?php echo e($anime->seasons); ?>">
            </div>
        </div>
        <div class="row mt-3">
            <div class="form-group col-6">
                <label for="studio" class="form-label">Estudio responsavel:</label>
                <input type="text" name="studio" id="studio" class="form-control" value="<?php echo e($anime->studio); ?>">
            </div>
            <div class="form-group col-6">
                <label for="authors" class="form-label">Autores:</label>
                <input type="text" name="authors" id="authors" class="form-control" value="<?php echo e($anime->authors); ?>">
            </div>
        </div>
        <div class="row mt-3">
            <div class="form-group col-12">
                <label for="synopsis" class="form-label">Sinopse: </label>
                <textarea  id="synopsis" name="synopsis" rows="3" class="form-control" style="resize: none"><?php echo e($anime->synopsis); ?></textarea>
            </div>
        </div>
        <div class="row mt-3">
            <div class="form-group col-12">
                <label for="image" class="form-label">Link da Imagem:</label>
                <input type="text" name="image" id="image" class="form-control" value="<?php echo e($anime->image); ?>">
            </div>
        </div>
        <input type="submit" class="btn btn-success mt-3">
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Vinícius FM\Documents\code\CursoLaravel\Nova pasta\PFC-SiteDeAnimes\pfc\resources\views/animes/edit.blade.php ENDPATH**/ ?>