<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['title' => 'Listagem animes']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Listagem animes']); ?>

        <a href="<?php echo e(route('animes.create')); ?>" class="btn btn-warning mt-4 mb-4">Criar anime</a>

    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Capa</th>
            <th scope="col">Nome</th>
            <th scope="col">Lancamento</th>
            <th scope="col">Qt. Eps</th>
            <th scope="col">Qt. Temps</th>
            <th scope="col">Estudios</th>
            <th scope="col">Autores</th>
            <th scope="col">Sinopse</th>
            <th scope="col">Editar</th>
            <th scope="col">Excluir</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $animes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="max-height: 100px">

                <th><img src="<?php echo e($anime->image); ?>" alt="<?php echo e($anime->name); ?>"></th>
                <th><?php echo e($anime->name); ?></th>
                <th><?php echo e($anime->date); ?></th>
                <th><?php echo e($anime->episodes); ?></th>
                <th><?php echo e($anime->seasons); ?></th>
                <th><?php echo e($anime->studio); ?></th>
                <th><?php echo e($anime->authors); ?></th>
                <th><?php echo e($anime->synopsis); ?></th>
                <th><a href="<?php echo e(route('animes.edit', $anime->id)); ?>" class="btn btn-primary btn-sm" style="height: 30px; width: 30px">✎</a></th>
                <th><form action="<?php echo e(route('animes.destroy', $anime->id)); ?>" method="POST" class="ms-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sn" style="width: 30px; height: 30px">
                        🗑
                    </button>
                </form></th>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        </tbody>
    </table>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Vinícius FM\Documents\code\CursoLaravel\Nova pasta\PFC-SiteDeAnimes\pfc\resources\views/animes/index.blade.php ENDPATH**/ ?>